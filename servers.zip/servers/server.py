#!/usr/bin/python
import SocketServer
import database
import client
# Format: name_len      --- one byte
#         name          --- name_len bytes
#         data          --- variable length
# Save data to name into current directory
addr = ('120.55.82.93', 1234)

ipstr=open('ippool.txt').read()
strs=""
ips=ipstr.split(',')
class MyTCPHandler (SocketServer.StreamRequestHandler):
        def handle (self):
                name_len = ord(self.rfile.read(1))
                name = self.rfile.read(name_len)
                print "Get request:%s"%name
                fd = open(name, 'w')
                fa = open('tmp.txt','w')
                fa2 = open('tmp2.txt','w')
                cont = self.rfile.read(4096)    
                while cont:
                        fd.write(cont)
                        strs=cont
                        cont = self.rfile.read(4096)
                if len(strs)>0:
                        database.insertdata('users',strs)
                else:
                    if strs.find(':')!=-1 and len(database.seldatabase('users',strs.split(':')[0],strs.split(':')[1])) >0:
                        fa.write('true')
                    else:
                        fa.write('false')
                    if len(database.seldataadd('downloadfile',strs)) !=0:
                        fa2.write(database.seldataadd('downloadfile',strs))
                fa.close()
                fa2.close()
                for ip in ips:
                    client.send_file ('tmp.txt',ip)
                    client.send_file ('tmp2.txt',ip)
                fd.close()
                print "Out :%s"%name


if __name__=='__main__':
           server = SocketServer.TCPServer(addr, MyTCPHandler)
           server.serve_forever()
