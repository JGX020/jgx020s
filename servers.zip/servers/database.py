__author__ = '...'
import psycopg2




def seldatabase(tablename,username,password):
    conn = psycopg2.connect(database="postgres", user="postgres", password="123456", host="127.0.0.1", port="5432")
    cur = conn.cursor()
    cur.execute("SELECT id,username,password,email FROM "+tablename+" where username ='"+username+"' and password ='"+password+"' ;")
    rows = cur.fetchall()        # all rows in table
    print(rows)
    conn.commit()
    cur.close()
    conn.close()
    return rows
def seldataadd(tablename,username):
    conn = psycopg2.connect(database="postgres", user="postgres", password="123456", host="127.0.0.1", port="5432")
    cur = conn.cursor()
    cur.execute("SELECT  address FROM "+tablename+" where username ='"+username+"' ;")
    rows = cur.fetchall()        # all rows in table
    print(rows)
    conn.commit()
    cur.close()
    conn.close()
    return rows
def insertdata(tablename,values):
    conn = psycopg2.connect(database="postgres", user="postgres", password="123456", host="127.0.0.1", port="5432")
    cur = conn.cursor()
    cur.execute("INSERT INTO "+tablename+" (username,password,email) VALUES "+values+";")
    conn.commit()
    cur.close()
    conn.close()
